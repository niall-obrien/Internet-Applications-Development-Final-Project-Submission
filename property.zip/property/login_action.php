<?php

	//Start the session
	session_start();

	require 'connect.php';

	//If the form is submitted
	if(isset($_POST['admin_email']) and isset($_POST['password'])){

		//function to clean data entered
		function validate($data){

			$data = trim($data);
			$data = stripslashes($data);
			$data = htmlspecialchars($data);
			return $data;

		}

		//Assigning posted values to vars.
		$username = validate($_POST['admin_email']);
		$password = validate($_POST['password']);

		if(empty($username)){

			$_SESSION['errors'] = array('User Name is required');
			header("Location:adminlogin.php");
			exit();

		}
		else if(empty($password)){

			$_SESSION['errors'] = array('Password is required');
			header("Location:adminlogin.php");
			exit();

		}
		else{

			//Check if values exist in db
			$query = "SELECT * FROM administrator WHERE admin_email = '$username' AND password = '$password'";
			$result = mysqli_query($link, $query) or die(mysqli_error($link));
			$count = mysqli_num_rows($result);

		

			//If posted values are equal to the db values, then session will be created for user.
			if($count == 1){

				$row = mysqli_fetch_array($result);
				$_SESSION['username'] = $row['firstname'];
				header ("Location:admin.php");
				exit;

			}
			else{

				//If login credentials don't match, show error message and return to login page
				$_SESSION['errors'] = array('Your username or password was incorrect');
				header("Location:adminlogin.php");

			}

		}

	}

?>