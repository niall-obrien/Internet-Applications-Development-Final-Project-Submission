<!DOCTYPE HTML>

<html lang="en">

  <head>

    <title>Contact Us</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href='https://fonts.googleapis.com/css?family=Source+Sans+Pro'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  </head>

  <body>

    <div id="container">

      <?php include("includes/header.html");?>
      <?php include("includes/nav.html");?>

      <div id="content">

        <strong>SafeAs Real Estate</strong><br>
        10 Hillside,<br>
        Ballydehob,<br>
        Co. Cork,<br>
        Ireland.<br>
        EIRCODE<br>
        <br>
        Email: info@safeasrealestate.ie<br>
        Phone: +353 (0)21 555 5555

      </div><!--close content-->

    <?php include("includes/footer.html");?>

    </div><!--close container--> 

  </body>

</html>
