<?php
require 'connect.php';
//following code checks if submit button is clicked and updates the data in the db accordingly
if(isset($_POST['submit']))
{
 //store the data posted in the form in variables and use real escape string to clean data fields the user can enter

 $propertyid=$_POST['propertyid'];
 $address=mysqli_real_escape_string($link,$_POST['address1']);
 $town=mysqli_real_escape_string($link,$_POST['town']);
 $county=mysqli_real_escape_string($link,$_POST['county']);
 $price=mysqli_real_escape_string($link,$_POST['price']);
 $bedrooms=$_POST['bedrooms'];
 $shortdescription=mysqli_real_escape_string($link,$_POST['shortdescription']);
 $longdescription=mysqli_real_escape_string($link,$_POST['longdescription']);
 $vendor_email=$_POST['vendor_email'];
 $categoryid=$_POST['category'];
 $image=mysqli_real_escape_string($link,$_POST['image']);
 
 //query to update the fields in the property table
 $sql= "UPDATE property SET address1='$address', town='$town', county='$county', bedrooms='$bedrooms', price='$price',
longdescription='$longdescription', shortdescription='$shortdescription', vendor_email='$vendor_email',
categoryid='$categoryid', image='$image' WHERE propertyid=$propertyid";

 //if the query is successful return to the manageproperties page, otherwise output an error message
 if (mysqli_query( $link, $sql))
 {
 header("Location: http://localhost/property/manageproperties.php");
 exit;
 }
 else
{
 echo "Could not update property";
}
}
mysqli_close($link);
?>