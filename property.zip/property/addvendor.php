<!DOCTYPE HTML>

<html lang="en">

  <head>

    <title>Add a Vendor</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href='https://fonts.googleapis.com/css?family=Source+Sans+Pro'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  </head>

  <body>

    <div id="container">

      <?php include("includes/header.html");?>
      <?php include("includes/nav.html");?>

      <div id="content">

        <h3>Enter Vendor Details</h3>
        <p>

          <div id = "addvendor">

            <form method = "post" action = "processaddvendor.php">

              <table>
                <tr>
                  <td>Vendor Email: </td>
                  <td><input type="text" name="vendor_email" placeholder = "Enter vendor email" required = "required"/></td>
                </tr>
                <tr>
                  <td>Vendor First Name: </td>
                  <td><input type="text" name="vendor_firstname" placeholder = "Enter vendor first name" required = "required"/></td>
                </tr>
                <tr>
                  <td>Vendor Surname: </td>
                  <td><input type="text" name="vendor_surname" placeholder = "Enter vendor surname" required = "required"/></td>
                </tr>
                <tr>
                  <td>Vendor Phone Number: </td>
                  <td><input type="text" name="vendor_phone" placeholder = "Enter vendor phone no." 
                    required = "required"/></td>
                </tr>
                <tr>
                  <td><input type="submit" name="submit" value = "Add Vendor"/></td>
                </tr>
              </table>
            </form>

            <p><a href='managevendor.php'>Manage Vendor</a></p>
            <p><a href='admin.php'>Admin Menu</a></p>
          
          </div><!--close addvendor-->

      </div><!--close content-->

    <?php include("includes/footer.html");?>

    </div><!--close container--> 

  </body>

</html>