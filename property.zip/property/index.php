<!DOCTYPE HTML>
<html lang="en">

  <head>

    <title>Home</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href='https://fonts.googleapis.com/css?family=Source+Sans+Pro'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  </head>

  <body>

    <div id="container">

      <?php include("includes/header.html");?>
      <?php include("includes/nav.html");?>

      <div id="content">

        <h3>Welcome to SafeAs Real Estate</h3>
        SafeAs Real Estate since it was established by John o'Driscoll in 1992 has been providing property opportunities to the local, national and international markets.
        With an experienced team of agents to guide through your property journey we endeavour to find the property that suits you.

      </div>

      <?php include("includes/footer.html");?>

    </div><!--close container-->

  </body>

</html>