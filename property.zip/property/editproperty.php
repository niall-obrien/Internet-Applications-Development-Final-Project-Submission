<!DOCTYPE HTML>

<html lang="en">

  <head>

    <title>Edit Property</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href='https://fonts.googleapis.com/css?family=Source+Sans+Pro'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  </head>

  <body>

    <div id="container">

      <?php include("includes/header.html");?>
      <?php include("includes/nav.html");?>

      <div id="content">

        <div class='left'>
          <p><a href='manageproperties.php'>Manage Properties</a></p>
        </div>
        <div class='right'>
          <p><a href='admin.php'>Admin Menu</a>
            <a href = 'logout.php'>Logout</a></p>
        </div>

        <?php

          require 'connect.php';

          $propertyid = $_GET["propertyid"];//retrieve propertyid passed in url
          $sql = "SELECT * FROM property, category WHERE propertyid = $propertyid AND 
            category.categoryid = property.categoryid";
          $result = mysqli_query($link, $sql);//run query
          $row = mysqli_fetch_array($result);//store recordset in $row

          //retrieve database field from recordset and assign to vars for output
          $propertyid = $row["propertyid"];
          $address = $row["address1"];
          $town = $row["town"];
          $county = $row["county"];
          $bedrooms = $row["bedrooms"];
          $price = $row["price"];
          $shortdescription = $row["shortdescription"];
          $longdescription = $row["longdescription"];
          $vendor_email = $row["vendor_email"];
          $categoryid = $row["categoryid"];
          $categoryname = $row["categoryname"];
          $image = $row["image"];

        ?>
        
        <!--write existing fields into form fields-->
        <form method = "post" action = "processedit.php">

          <input type = "hidden" name = "propertyid" value = "<?php echo $propertyid; ?>"/>

          <table>

            <tr>
              <td><strong>Edit Property</strong></td>
              <td><?php echo "<img src = '$image' width = 100 height = 100" ?>;</td>
            </tr>
            <tr>
              <td>Address: </td><td><input type="text" name="address1" value = "<?php echo 
              $address; ?>"></td>
            </tr>
            <tr>
              <td>Town: </td><td><input type="text" name="town" value = "<?php echo 
              $town; ?>"></td>
            </tr>
            <tr>
              <td>County: </td><td><input type="text" name="county" value = "<?php echo 
              $county; ?>"></td>
            </tr>
            <tr>
              <td>Bedrooms: </td><td><input type="text" name="bedrooms" value = "<?php echo 
              $bedrooms; ?>"></td>
            </tr>
            <tr>
              <td>Price: </td><td><input type="text" name="price" value = "<?php echo $price; ?>"/></td>
            </tr>
            <tr>
              <td>Short Description: </td><td><textarea name = "shortdescription" rows = "8" cols = "35"><?php echo $shortdescription;?></textarea></td>
            </tr>
            <tr>
              <td>Further Details: </td><td><textarea name = "longdescription" rows = "8" cols ="35"><?php echo $longdescription; ?></textarea></td>
            </tr>
            <tr>
              <td>Vendor Email: </td>
              <td>

                <!--create a select box with dropdown email options taken from the database as this is more user friendly-->
                <select name = "vendor_email" required = "required">
                  <?php 
                    echo "<option value='$vendor_email'>$vendor_email</option>";//display current value at top
                    $sql = "SELECT vendor_email FROM vendor WHERE vendor_email!='$vendor_email'";//choose all other possible options from the database
                    $result = mysqli_query($link, $sql);//run the query

                    if(mysqli_num_rows($result) > 0){//if result exists display as dropdown menu

                      while($row = mysqli_fetch_array($result)){

                        $vendor_email = $row['vendor_email'];
                        echo "<option value='$vendor_email'>$vendor_email</option>";//set the value of option selected and show user the possible email addresses

                      }

                    }

                  ?>
                </select>
              </td>
            </tr>
            <tr>
              <td>Category</td>
              <td>
                <!--create select box with dropdown category from database-->
                <select name = "category" required = "required">
                  <?php
                    
                    echo "<option value='$categoryid'>$categoryname</option>";//display current value at top
                    $sql = "SELECT * FROM category WHERE categoryid!=$categoryid";//choose all  other possible options
                    $result = mysqli_query($link, $sql);

                    if(mysqli_num_rows($result) > 0){

                      while($row = mysqli_fetch_array($result)){

                        $categoryname = $row['categoryname'];
                        $categoryid = $row['categoryid'];

                        echo "<option value = '$categoryid'>$categoryname</option>";

                      }

                    }
                    
                  ?>
                </select>
              </td>
            </tr>
            <tr>
              <td>Image path: </td>
              <td><input type = "text" name = "image" value = "<?php echo $image;?>"/></td>
            </tr>
            <tr>
              <td><input type = "submit" name = "submit" value = "Update Property"/></td>
            </tr>

          </table>

        </form>
        
        <?php mysqli_close($link); ?>

      </div><!--close content-->

      <?php include("includes/footer.html");?>

    </div><!--close container--> 

  </body>

</html>
