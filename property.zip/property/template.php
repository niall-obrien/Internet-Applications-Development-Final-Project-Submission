<!DOCTYPE HTML>

<html lang="en">

  <head>

    <title>Template</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  </head>

  <body>

    <div id="container">

      <?php include("includes/header.html");?>
      <?php include("includes/nav.html");?>

      <div id="content">

        

      </div><!--close content-->

    <?php include("includes/footer.html");?>

    </div><!--close container--> 

  </body>

</html>
