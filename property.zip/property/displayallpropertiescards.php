<!DOCTYPE HTML>
<html lang="en">

  <head>

    <title>Display All Properties Cards</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href='https://fonts.googleapis.com/css?family=Source+Sans+Pro'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
  </head>

  <body>

    <div id="container">

      <?php include("includes/header.html");?>
      <?php include("includes/nav.html");?>

      <div id="content">

        <div id="displayproperties">

          <?php

            require "connect.php"; //access the connection code

            $sql="SELECT * FROM property";
            $result=mysqli_query($link, $sql);

            if(mysqli_num_rows($result)>0){ //check are there records in the result set

              echo "<h3>All Properties</h3>";
              echo "<div class='card-area'>";//set up the flex container

              while($row=mysqli_fetch_array($result)){ //while there are records...
              
                $propertyid=$row["propertyid"];
                $image=$row["image"];
                $address=$row["address1"];
                $town=$row['town'];
                $county=$row['county'];
                $categoryid=$row['categoryid'];
                $shortdescription=$row["shortdescription"];
                $bedrooms=$row["bedrooms"];
                $price=$row["price"];

                echo "<div class='card'>"; //create a card - each card is a child of the card-area flex container
                  echo "<div class='image-holder'>"; //the image-holder is a div in the card to hold the image
                    echo "<img src='$image' alt='employee' >";
                  echo "</div>"; //close the image holder
                  echo "<div class='cardcontainer'>"; //this container div adds a horizontal rule and holds  the product name, description and price
                    echo "<hr>";
                    echo "<h4>$address</h4>";//output the property address
                    echo "<p>$town, $county</p>";
                    echo "<p>Bedrooms $bedrooms</p>";//output the no of bedrooms
                    echo "<p>&euro; $price</p>"; //output the euro sign and price
                    echo "<p>$shortdescription</p>"; //output the chort description
                    echo "<div class='moredetails'>"; //this div contains the moredetails button
                      echo "<p><a href='moredetails.php?propertyid=$propertyid'>More Details</a></p>";
                    echo "</div>"; //close the moredetails div
                  echo "</div>"; //close the cardcontainer div
                echo "</div>"; //close the card

              } //end while loop

              echo "</div>"; //close the flex containersince no more records

            }
            else{ //if there are no records in the result set
            
              echo "<h3>There are no products in the database</h3>"; //output a message

            }

            mysqli_close($link); //close the connection

          ?>

        </div> <!-- close the displayproducts div--> 

      </div><!-- close the content div--> 

      <?php include("includes/footer.html");?>

    </div><!-- close the container div--> 

  </body>

</html>
