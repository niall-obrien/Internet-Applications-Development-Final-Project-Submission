<!DOCTYPE HTML>

<html lang="en">

  <head>

    <title>Add a Property</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href='https://fonts.googleapis.com/css?family=Source+Sans+Pro'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  </head>

  <body>

    <div id="container">

      <?php include("includes/header.html");?>
      <?php include("includes/nav.html");?>

      <div id="content">

        <div class='left'>
          <p><a href='manageproperties.php'>Manage Properties</a></p>
        </div>
        <div class='right'>
          <p><a href='admin.php'>Admin Menu</a>
            <a href = 'logout.php'>Logout</a></p>
        </div>

          <div id = "addproduct">

            <form method = "post" action = "processadd.php">

              <table>
                <td><strong>Add a Property</strong></td>
                <td></td>
                <tr>
                  <td>Address: </td>
                  <td><input type="text" name="address1" placeholder = "Enter property address" required = "required"/></td>
                </tr>
                <tr>
                  <td>Town: </td>
                  <td><input type="text" name="town" placeholder = "Enter town" required = "required"/></td>
                </tr>
                <tr>
                  <td>County: </td>
                  <td><input type="text" name="county" placeholder = "Enter county" required = "required"/></td>
                </tr>
                <tr>
                  <td>Price: </td>
                  <td><input type="text" name="price" placeholder = "Enter property price" 
                    required = "required"/></td>
                </tr>
                <tr>
                  <td>Bedrooms: </td>
                  <td><input type="text" name="bedrooms" placeholder = "Enter number of bedrooms" 
                    required = "required"/></td>
                </tr>
                <tr>
                  <td>Description: </td>
                  <td><textarea name = "shortdescription" rows = "8" cols = "35" 
                    placeholder = "Enter product short description" required = "required"/></textarea>
                  </td>
                </tr>
                <tr>
                  <td>Long Description: </td>
                  <td><textarea name = "longdescription" rows = "8" cols = "35"
                    placeholder = "Enter product long description" required = "required"/></textarea>
                  </td>
                </tr>
                  <td>Vendor Email: </td>
                  <td>
                    <!--create select box with dropdown email options taken from database-->
                    <select name = "vendor_email" required = "required">
                      <option>Select Vendor</option>
                      <?php

                        require 'connect.php';

                        $sql = "SELECT vendor_email FROM vendor"; //choose all possible options from database
                        $result = mysqli_query($link, $sql);//run the query

                        if(mysqli_num_rows($result) > 0){

                          while($row = mysqli_fetch_array($result)){

                            $vendor_email = $row['vendor_email'];
                            echo "<option value = '$vendor_email'>$vendor_email</option>"; //set value of option selected and show user possible email addresses

                          }

                        }

                      ?>
                    </select>
                  </td>
                </tr>
                <tr>
                  <td>Category ID: </td>
                  <td>
                    <!--create select box with dropdown category option from database-->
                    <select name = "category" required = "required">
                      <option>Select Category</option>
                      <?php

                        $sql="SELECT * FROM category"; //choose all possible options from db
                        $result=mysqli_query($link, $sql); //run query

                        if(mysqli_num_rows($result) > 0){ //if records exist, output as dropdown

                          while($row=mysqli_fetch_array($result)){

                            $categoryname=$row['categoryname'];
                            $categoryid=$row['categoryid'];
                            echo"<option value = '$categoryid'>$categoryname</option>"; //set value of option selected to categoryid but show category name

                          }

                        }

                        mysqli_close($link);

                      ?>
                    </select>
                  </td>
                </tr>
                <tr>
                  <td>Image Path: </td>
                  <td><input type="text" name="image" placeholder = "Enter image path" 
                    required = "required"/>
                  </td>
                </tr>
                <tr>
                  <td><input type="submit" name="submit" value = "Submit Property"/></td>
                </tr>
              </table>
            </form>

          </div><!--close addproduct-->

      </div><!--close content-->

    <?php include("includes/footer.html");?>

    </div><!--close container--> 

  </body>

</html>
