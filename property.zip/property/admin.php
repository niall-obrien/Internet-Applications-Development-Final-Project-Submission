<!DOCTYPE HTML>

<html lang="en">

  <head>

    <title>Admin</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href='https://fonts.googleapis.com/css?family=Source+Sans+Pro'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  </head>

  <body>

    <div id="container">

      <?php include("includes/header.html");?>
      <?php include("includes/nav.html");?>

      <div id="content">

        <h3>Admin Menu</h3>

        <?php

          session_start();

          if(isset($_SESSION['username'])){

            $username = $_SESSION['username'];
            echo nl2br("Hi " .$username. "!"."\n\n");

            echo"Choose one of the menu options to Manage Comments, Products or Vendors. &nbsp; &nbsp;";
            echo"<p><a href = 'manageproperties.php'>Manage Properties</a>
            <p><a href = 'managevendor.php'>Manage Vendors</a>
            <p><a href = 'managecomments.php'>Manage Comments</a>";

            echo"<p><a href = 'logout.php'>Logout</a>";

          }

        ?>

      </div><!--close content-->

    <?php include("includes/footer.html");?>

    </div><!--close container--> 

  </body>

</html>
