-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2021 at 11:22 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `giftcompany`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `admin_email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `surname` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`admin_email`, `password`, `firstname`, `surname`) VALUES
('evelyn@lyit.ie', 'password', 'Evelyn', 'Keown'),
('joe@test.com', 'testing', 'Joe', 'Bloggs');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `categoryid` int(11) NOT NULL,
  `categoryname` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`categoryid`, `categoryname`) VALUES
(1, 'Flowers'),
(2, 'Baby Girl'),
(3, 'Baby Boy'),
(4, 'Hampers'),
(5, 'Softtoys'),
(6, 'Valentine');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `author_name` varchar(100) NOT NULL,
  `author_email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','planned') NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `title`, `content`, `author_name`, `author_email`, `created_at`, `status`) VALUES
(2, 'brillo', 'great site', 'eve', 'eve@ko.com', '2017-02-14 16:33:28', 'planned'),
(10, 'This is a test', 'This is a test', 'testing', 'test@hotmail.com', '2017-02-14 19:23:40', 'pending'),
(21, 'hi', 'hello there', 'evelyn', 'evelyn@test.com', '2017-02-16 13:40:51', 'pending'),
(22, 'just testing what will happen', 'if i leave a really long comment if i leave a really long comment if i leave a really long comment', 'tesing', 'hello@otc.ie', '2017-02-16 13:49:30', 'planned'),
(23, 'Great service!', 'Thanks for my order - it arrived safely and on time.', 'Joe', 'joe@hotmail.com', '2017-02-19 10:37:23', 'planned'),
(24, 'Love this Site', 'Great quality products. customer service second to none!', 'Les', 'Les@lse.uk', '2017-02-19 11:30:00', 'pending'),
(31, 'Test', 'Just testing is this working', 'Evelyn Keown', 'ejk@hotmail.com', '2019-02-09 21:09:58', 'pending'),
(38, 'Hello', 'Great product and great service!', 'danny', 'dan@test.com', '2021-05-23 12:42:55', 'planned');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `productid` int(11) NOT NULL,
  `productname` varchar(50) NOT NULL,
  `price` double(5,2) NOT NULL,
  `description` text NOT NULL,
  `longdescription` text NOT NULL,
  `vendor_email` varchar(50) NOT NULL,
  `categoryid` int(11) NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`productid`, `productname`, `price`, `description`, `longdescription`, `vendor_email`, `categoryid`, `image`) VALUES
(1, 'Soft Hairbrush', 12.99, 'This is a gentle hairbrush suitable from newborn. ', 'We could add a lot more details about the product to this field and it would show up when we click on the more details link. We could also add a shopping cart facility to this page if we were going to implement the site.', 'helen@giftsgalore.co.uk', 2, 'images/brush.jpg'),
(3, 'Baby Shoes', 19.99, 'These stunning shoes are perfect for your precious baby girl on a special occasion!', 'We could add a lot more details about the product to this field and it would show up when we click on the more details link. We could also add a shopping cart facility to this page if we were going to implement the site.', 'info@kidz.com', 2, 'images/babyshoes.jpg'),
(4, 'Rose Bouquet', 29.99, 'A beautiful bouquet of 12 fresh roses for your loved one!', 'We could add a lot more details about the product to this field and it would show up when we click on the more details link. We could also add a shopping cart facility to this page if we were going to implement the site.', 'helen@giftsgalore.co.uk', 1, 'images/12roses.jpg'),
(5, 'Doll', 15.99, 'Beautiful soft doll', 'We could add a lot more details about the product to this field and it would show up when we click on the more details link. We could also add a shopping cart facility to this page if we were going to implement the site.', 'info@kidz.com', 2, 'images/doll.jpg'),
(6, 'Blue Brush', 12.99, 'Beautiful blue hairbrush. ', 'This brush is suitable from birth. It has soft bristles and would make a lovely gift for a newborn baby.', 'helen@giftsgalore.co.uk', 2, 'images/bluebrush.jpg'),
(7, 'Gift', 6.99, 'Random gift.', 'Lots more details will go in here in this long description...', '', 2, 'images/gift.jpg'),
(8, 'Red Hairband', 3.99, 'Hairband.', 'Lots more info to go here....', 'info@kidz.com', 2, 'images/hairband.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE `vendor` (
  `vendor_email` varchar(50) NOT NULL,
  `vendor_name` varchar(50) NOT NULL,
  `vendor_phone` varchar(50) NOT NULL,
  `vendor_address` varchar(50) NOT NULL,
  `vendor_town` varchar(50) NOT NULL,
  `vendor_county` varchar(50) NOT NULL,
  `vendor_country` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vendor`
--

INSERT INTO `vendor` (`vendor_email`, `vendor_name`, `vendor_phone`, `vendor_address`, `vendor_town`, `vendor_county`, `vendor_country`) VALUES
('helen@giftsgalore.co.uk', 'Gifts Galore', '0044123456789', 'South Street', 'Manchester', 'Greater Manchester', 'England'),
('info@kidz.com', 'Kidz', '096123456', 'Hight Street', 'Naas', 'Kildare', 'Ireland'),
('keenan@hotmail.com', 'Keenan Toys', '086123456', 'Main Street', 'Letterkenny', 'Donegal', 'Ireland');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`admin_email`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`categoryid`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`productid`);

--
-- Indexes for table `vendor`
--
ALTER TABLE `vendor`
  ADD PRIMARY KEY (`vendor_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `categoryid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `productid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
