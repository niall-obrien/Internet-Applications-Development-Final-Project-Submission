<!DOCTYPE HTML>

<html lang="en">

  <head>

    <title>Edit Vendor</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href='https://fonts.googleapis.com/css?family=Source+Sans+Pro'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  </head>

  <body>

    <div id="container">

      <?php include("includes/header.html");?>
      <?php include("includes/nav.html");?>

      <div id="content">

        <div class='left'>
          <p><a href='managevendor.php'>Manage Vendors</a></p>
        </div>
        <div class='right'>
          <p><a href='admin.php'>Admin Menu</a>
            <a href = 'logout.php'>Logout</a></p>
        </div>

        <?php

          require 'connect.php';

          $vendor_email = $_GET["vendor_email"];//retrieve vendor_email passed in url
          $sql = "SELECT * FROM vendor WHERE vendor_email = '$vendor_email'";
          $result = mysqli_query($link, $sql);//run query
          $row = mysqli_fetch_array($result);//store recordset in $row

          //retrieve database field from recordset and assign to vars for output
          $vendor_email = $row["vendor_email"];
          $vendor_firstname = $row["vendor_firstname"];
          $vendor_surname = $row["vendor_surname"];
          $vendor_phone = $row["vendor_phone"];

        ?>
        
        <!--write existing fields into form fields-->
        <form method = "post" action = "processeditvendor.php">

          <table>
            <tr>
              <td><strong>Edit Vendor</strong><td>
            </tr>
            <tr>
              <td>First Name: </td><td><input type="text" name="vendor_firstname" value = "<?php echo $vendor_firstname; ?>"></td>
            </tr>
            <tr>
              <td>Surname: </td><td><input type="text" name="vendor_surname" value = "<?php echo 
              $vendor_surname; ?>"></td>
            </tr>
            <tr>
              <td>Phone No.: </td><td><input type="text" name="vendor_phone" value = "<?php echo 
              $vendor_phone; ?>"></td>
            </tr>
            <tr>
              <td>Vendor Email: </td><td><input type="text" name="vendor_email" value="<?php echo $vendor_email; ?>" readonly></td>
            </tr>
            <tr>
              <td><input type = "submit" name = "submit" value = "Update Vendor"/></td>
            </tr>

          </table>

        </form>
        
        <?php mysqli_close($link); ?>

      </div><!--close content-->

      <?php include("includes/footer.html");?>

    </div><!--close container--> 

  </body>

</html>