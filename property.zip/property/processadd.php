<!DOCTYPE HTML>

<html lang="en">

  <head>

    <title>Add a Property</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href='https://fonts.googleapis.com/css?family=Source+Sans+Pro'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  </head>

  <body>

    <div id="container">

      <?php include("includes/header.html");?>
      <?php include("includes/nav.html");?>

      <div id="content">

        <div class='right'>
          <p><a href='admin.php'>Admin Menu</a>
            <a href = 'logout.php'>Logout</a></p>
        </div><div class='left'>
          <p><a href='addproperty.php'>Return to Add Property</a></p>
        </div>

        <?php

          require 'connect.php';

          if(isset($_POST['submit'])){

            $address=mysqli_real_escape_string($link, $_POST['address1']);
            $town=mysqli_real_escape_string($link, $_POST['town']);
            $county=mysqli_real_escape_string($link, $_POST['county']);
            $price=mysqli_real_escape_string($link, $_POST['price']);
            $bedrooms=$_POST['bedrooms'];
            $shortdescription=mysqli_real_escape_string($link, $_POST['shortdescription']);
            $longdescription=mysqli_real_escape_string($link, $_POST['longdescription']);
            $vendor_email=$_POST['vendor_email'];
            $categoryid=$_POST['category'];
            $image=mysqli_real_escape_string($link, $_POST['image']);

            $sql_insert="INSERT INTO property(address1, town, county, price, bedrooms, shortdescription, longdescription, image, categoryid, vendor_email) VALUES('$address', '$town', '$county', '$price', '$bedrooms', '$shortdescription', '$longdescription', '$image', '$categoryid', '$vendor_email')";

            if(mysqli_query($link, $sql_insert)){

              echo"<h3>Property Added</h3>";
              echo"<a href='manageproperties.php'>Return to Manage Properties page</a>";

            }
            else{

              echo"An error occured, try again!";

            }

          }

          mysqli_close($link);

        ?>

      </div><!--close content-->

    <?php include("includes/footer.html");?>

    </div><!--close container--> 

  </body>

</html>
