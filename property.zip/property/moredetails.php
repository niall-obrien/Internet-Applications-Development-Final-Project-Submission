<!DOCTYPE HTML>

<html lang = "en">

  <head>

    <title>More Details</title>
    <meta charset = "utf-8">
    <link rel = "stylesheet" href = "css/styles.css">
    <link rel="stylesheet" href='https://fonts.googleapis.com/css?family=Source+Sans+Pro'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
  </head>

  <body>

    <div id = "container">

      <?php include("includes/header.html");?>
      <?php include("includes/nav.html");?>

      <div id = "content">

        <div id = "cardmoredetails">

          <?php
            
            $server = "localhost";
            $dbuser = "root";
            $password = "";
            $link = mysqli_connect($server,$dbuser,$password);
            mysqli_select_db($link,"property");
            
            $propertyid = $_GET["propertyid"];
            $sql = "SELECT * FROM property WHERE propertyid = $propertyid";
            $result = mysqli_query($link, $sql);
            
            $row=mysqli_fetch_array($result);
              
              $image = $row["image"];
              $address = $row["address1"]; 
              $town = $row["town"];
              $county = $row["county"];
              $bedrooms = $row["bedrooms"];
              $longdescription = $row["longdescription"];
              $price = $row["price"]; 
              
              echo"<div class='card-area'>";
                echo "<div class='cardmoredetails'>";
                  echo"<img src='$image' width=200 height=200 border=3px> <h3>";
                  echo "Address"; 
                  echo "</h3> $address <br><h3>";
                  echo "</h3> $town <br><h3>";
                  echo "</h3> $county <br><h3>";
                  echo "Bedrooms";
                  echo "</h3> $bedrooms <br><h3>";
                  echo "Price";
                  echo "</h3> &euro; $price <br><h3>";
                  echo "Property Description";
                  echo "</h3> $longdescription <h3>";
                echo "</div>";//close cardmoresetails
              echo "</div>";//close card-area  
   
            mysqli_close($link);
            
          ?>

        </div><!--close cardmoredetails-->

        <p>

          <button onclick="goBack()">Go Back to Property Listings</button>

            <script>

              function goBack() {

                window.history.back(); 

              }

            </script> 

        </p>
      
      </div><!--close content-->

      <?php include("includes/footer.html");?>

    </div><!--close container--> 

  </body>

</html>
