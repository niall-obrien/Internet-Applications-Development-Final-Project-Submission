<!DOCTYPE HTML>

<html lang="en">

  <head>

    <title>Manage Properties</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href='https://fonts.googleapis.com/css?family=Source+Sans+Pro'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  </head>

  <body>

    <div id="container">

      <?php include("includes/header.html");?>
      <?php include("includes/nav.html");?>

      <div id="content">

        <div class='left'>
          <p><a href='addproperty.php'>Add Property</a></p>
        </div>
        <div class='right'>
          <p><a href='admin.php'>Admin Menu</a>
            <a href = 'logout.php'>Logout</a></p>
        </div>


        <div id = "displayproperties">

          <?php

            $server = "localhost";
            $dbuser = "root";
            $password = "";
            $link = mysqli_connect($server, $dbuser, $password);
            mysqli_select_db($link, "property");

            $sql = "SELECT * from property";
            $result = mysqli_query($link, $sql);

            if(mysqli_num_rows($result)>0){

              echo "<table>";
                echo "<tr>
                        <td><strong>Image</td>
                        <td><strong>Property ID</td>
                        <td><strong>Address</td>
                        <td><strong>Town</td>
                        <td><strong>County</td>
                        <td><strong>Bedrooms</td>
                        <td><strong>Price</td>
                        <td><strong>Edit</td>
                        <td><strong>Delete</td>
                      </tr>";

                while($row = mysqli_fetch_array($result)){

                  $propertyid = $row["propertyid"];
                  $image = $row["image"];
                  $address = $row["address1"];
                  $town = $row["town"];
                  $county = $row["county"];
                  $bedrooms = $row["bedrooms"];
                  $price = $row["price"];

                  echo "<tr>
                          <td><img src = '$image' width = 100 height = 100></td>
                          <td>$propertyid</td>
                          <td>$address</td>
                          <td>$town</td>
                          <td>$county</td>
                          <td>$bedrooms</td>
                          <td>&euro; $price</td>
                          <td><a href='editproperty.php?propertyid=$propertyid'>Edit</a></td>
                          <td><a href='confirmdeleteproperty.php?propertyid=$propertyid'>Delete</a></td>
                        </tr>";

                }

              echo "</table>";

            }
            else{

              echo "There are no products in the database";

            }

            mysqli_close($link);

          ?>

        </div><!--close displayproperties-->

      </div><!--close content-->

      <?php include("includes/footer.html");?>

    </div><!--close container--> 

  </body>

</html>
