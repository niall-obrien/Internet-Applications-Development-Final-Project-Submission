<!DOCTYPE HTML>

<html lang="en">

  <head>

    <title>Process Add Vendor</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href='https://fonts.googleapis.com/css?family=Source+Sans+Pro'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  </head>

  <body>

    <div id="container">

      <?php include("includes/header.html");?>
      <?php include("includes/nav.html");?>

      <div id="content">

        <?php

          require 'connect.php';

          if(isset($_POST['submit'])){

            $vendor_email = mysqli_real_escape_string($link, $_POST['vendor_email']);
            $vendor_firstname = mysqli_real_escape_string($link, $_POST['vendor_firstname']);
            $vendor_surname = mysqli_real_escape_string($link, $_POST['vendor_surname']);
            $vendor_phone = mysqli_real_escape_string($link, $_POST['vendor_phone']);
            $sql_insert = "INSERT INTO vendor (vendor_email, vendor_firstname, vendor_surname, vendor_phone) VALUES ('$vendor_email', '$vendor_firstname', '$vendor_surname', '$vendor_phone')";

            if(mysqli_query($link, $sql_insert)){

              echo"<h3>Vendor Added</h3>";
              echo"<a href = 'managevendor.php'>Return to Manage Vendors page</a>";

            }
            else{

              echo"An error occured, try again!";

            }

          }

          mysqli_close($link);

        ?>

      </div><!--close content-->

    <?php include("includes/footer.html");?>

    </div><!--close container--> 

  </body>

</html>