<?php

	require 'connect.php';

	//following code checks if submit button is clicked and updates the data in the db accordingly
	if(isset($_POST['submit'])){

		//store the data posted in form in vars and use real escape string to clean data fields
		$vendor_firstname=mysqli_real_escape_string($link, $_POST['vendor_firstname']);
		$vendor_surname=mysqli_real_escape_string($link, $_POST['vendor_surname']);
		$vendor_phone=mysqli_real_escape_string($link, $_POST['vendor_phone']);
		$vendor_email=$_POST['vendor_email'];

		//query to update the fields in the products table
		$sql="UPDATE vendor SET vendor_firstname='$vendor_firstname', vendor_surname='$vendor_surname', vendor_phone='$vendor_phone' WHERE vendor_email='$vendor_email'";

		//if query is successful return to manageproducts page, otherwise output an error message
		if(mysqli_query($link, $sql)){

			header("Location: http://localhost/property/managevendor.php");
			exit;

		}
		else{

			echo "Could not update vendor";

		}

	}

	mysqli_close($link);

?>